import { useContext, useEffect, useState } from "react";

import userContext from "./context/userContext";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

const AuthApp = () => {
  // const [dataBase, setDataBase] = useState([]);
  const [loggedInuser, setLoggedInuser] = useState({});
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [allUser, setAllUser] = useState([]);
let arr=[]
  useEffect(() => {
    let data = JSON.parse(localStorage.getItem("dataBase")) 
    setAllUser(data)
    // console.log(allUser)
    // console.log(data , "data on load");

    const loginStatus = JSON.parse(localStorage.getItem("isLoggedIn"));

    setIsLoggedIn(loginStatus);

    // setDataBase(data);
    // console.log(dataBase, "database data useEff");
    // setAlluserdata(...alluserdata,data,"Alluser data onload");
    // alluserdata = [...alluserdata,data]

  }, []);

  return (
    <>
      <userContext.Provider
        value={{ isLoggedIn, loggedInuser, allUser }}
      >
        <Home />
        <Login />
        <Signup />
      </userContext.Provider>
    </>
  );
};

export default AuthApp;
