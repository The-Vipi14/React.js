import { useContext, useState } from "react";
import userContext from "../context/userContext";
const Signup = () => {
  const { isLoggedIn, allUser } = useContext(userContext);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [userExists, setUserExists] = useState(false);
  const createUser = (e) => {
    e.preventDefault();

    if (!username || !email || !password) {
      alert("enter valid credentials");
    }
    const newUser = {
      username: username,
      email: email,
      password: password,
    };
    // dataBase.map((user) => {
    //   if (email === user.email) {
    //     alert("user exists alraedy.");
    //     setUserExists(true);
    //   }
    // });

    setUserExists(allUser.some((user) => user.email === email));

    console.log(userExists, "is user");
    if (userExists) {
      alert("user exists already.");
      return;
    } else {
      const updatedDataBase = [...allUser, newUser];
      localStorage.setItem("dataBase", JSON.stringify(updatedDataBase));

      console.log(allUser, "alluser data while i am creating new account ");
      console.log(userExists, "user exists status when i am creating new one");

      // setDataBase(updatedDataBase);

      // console.log(dataBase, "dfkjda");
      console.log("user registered successfully.");
      console.log(allUser);
    }
  };
  return (
    <>
      <form
        onSubmit={createUser}
        className="max-w-md text-red-50 mx-auto mt-10 bg-white dark:bg-gray-900 shadow-lg rounded-2xl p-6 space-y-6"
      >
        <h2 className="text-2xl font-semibold text-center">Sign Up</h2>

        <div className="space-y-4">
          <div className="flex flex-col gap-1">
            <label htmlFor="username" className="text-sm font-medium">
              Username
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="bg-amber-200/60 px-3 py-2 rounded-lg outline-none border focus:border-amber-400"
              placeholder="Enter username"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label htmlFor="email" className="text-sm font-medium">
              Email
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-amber-200/60 px-3 py-2 rounded-lg outline-none border focus:border-amber-400"
              placeholder="Enter email"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label htmlFor="password" className="text-sm font-medium">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-amber-200/60 px-3 py-2 rounded-lg outline-none border focus:border-amber-400"
              placeholder="Enter password"
            />
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-medium transition"
        >
          Create
        </button>
      </form>
    </>
  );
};

export default Signup;
